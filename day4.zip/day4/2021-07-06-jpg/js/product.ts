class ProductTs {
    public dimensions: [{} | string]|undefined;
    constructor(private id: number,
        public name: string,
        public price: number,
        public description: string | number,
        dimensions?: [{} | string]) {
        this.dimensions = dimensions;
        console.log(this);
    }
}
class ProductsTs extends Array<ProductTs>{
    constructor() {
        super();
    }
}
let productTs: ProductTs = new ProductTs(0,
    'Zodiax',
    100_000,
    'Magnifique bateau gonflable à coque rigide',
    [{ speed: '25noeud' },]);

const productsTs: ProductsTs = new ProductsTs();
products.push(productTs);
products.push(productTs);
console.log(productsTs,productTs);
