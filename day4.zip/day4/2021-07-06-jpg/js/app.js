//import du metier
import { DOMProducts } from './metierDom.js';
console.log('%c%s','color:red;font-weight:900;font-size:48pt','DEMAT BREIZH')
const products = new DOMProducts('#list');
function onsearchchange(evt) {
    evt.target.style.backgroundColor = "white";

    const regex = /^[a-z]{3,}$/;
    const searchval = evt.target.value;
    if (regex.exec(searchval) === null) {
        if(searchval.length>=3)evt.target.style.backgroundColor = "tomato";
        return;
    }
    console.log(searchval);
    products.makeSearch(searchval);
}
function initDomEvent() {
    document.querySelector('#finder input').addEventListener('input', onsearchchange)
}
initDomEvent();