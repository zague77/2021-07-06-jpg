import {createStore} from 'redux';
export default createStore(reducer);