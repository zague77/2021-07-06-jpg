import React, { Component } from 'react'
import { Text, View } from 'react-native'

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {}
  }
  componentDidMount() { }

  render() {
    return (
      <View>
        <Text>Demat breizh</Text>
      </View>
    )
  }
}