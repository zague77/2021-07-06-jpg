export const REST_SRV='http://desorbaix.alexandre.free.fr/phpRest';

